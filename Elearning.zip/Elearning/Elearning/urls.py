from django.contrib import admin
from django.urls import path
from django.conf.urls import url
from django.conf.urls.static import static
from django.contrib.staticfiles.urls import staticfiles_urlpatterns
from Elearning import settings
from course import views

urlpatterns = [
    path('admin/', admin.site.urls),
    path('', views.index, name='index'),
    path('login', views.login, name='login'),
    path('registration', views.reg, name='reg'),
    path('logout', views.logout, name='logout'),


    # ----------------- Faculty ----------------

    path('Faculty_Home', views.fac_home, name='fac_home'),
    path('Faculty_Courses', views.fac_course, name='fac_course'),
    url(r'^Faculty_Course_Topics/(?P<id>[0-9]+)', views.fac_course_topic, name='fac_course_topic'),
    path('Faculty_Inbox', views.fac_inbox, name='fac_inbox'),
    url(r'^Faculty_Inbox_Ans/(?P<id>[0-9]+)', views.fac_inbox_ans, name='fac_inbox_ans'),
    path(r'^Faculty_Inbox_Ans_2/', views.fac_inbox_ans_2, name='fac_inbox_ans_2'),
    path('Faculty_Profile', views.fac_profile, name='fac_profile'),

    # ----------------- Student ----------------

    path('Student_Home', views.std_home, name='std_home'),
    url(r'^Student_Topics/(?P<id>[0-9]+)', views.std_course_topic, name='std_Course_Topic'),
    url(r'^Student_Topic_video/(?P<id>[0-9]+)', views.std_course_topic_video, name='std_course_topic_video'),
    path('Student_Query', views.std_query, name='std_query'),
    path('Student_Inbox', views.std_inbox, name='std_inbox'),

    path('Student_Profile', views.std_profile, name='std_profile'),

    # ------------------- Admin -----------------

    path('admin_student_list', views.admin_student_list, name='admin_student_list'),
    path('admin_faculty_list', views.admin_faculty_list, name='admin_faculty_list'),
    path('admin_student_report', views.admin_std_report, name='admin_student_report'),
    path('admin_faculty_report', views.admin_faculty_report, name='admin_faculty_report'),

]
urlpatterns += staticfiles_urlpatterns()
urlpatterns += static(settings.STATIC_URL, document_root=settings.STATIC_URL)

if True:
    urlpatterns += static(settings.MEDIA_URL, document_root=settings.MEDIA_ROOT)
