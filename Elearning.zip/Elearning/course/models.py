from django.db import models


class Users(models.Model):
    user_name = models.CharField(max_length=100, blank=True, null=True)
    user_pass = models.CharField(max_length=100, blank=True, null=True)
    user_roll_no = models.CharField(max_length=100, blank=True, null=True)
    user_role = models.CharField(max_length=10, blank=True, null=True)

    def __str__(self):
        return self.user_name

    class Meta:
        verbose_name_plural = 'Users'


class CourseVideo(models.Model):
    course_faculty_id = models.CharField(max_length=100, blank=True, null=True)
    course_name = models.CharField(max_length=100, blank=True, null=True)
    course_video_title = models.CharField(max_length=100, blank=True, null=True)
    course_video = models.FileField(upload_to="", blank=True, null=True)

    def __str__(self):
        return self.course_name

    class Meta:
        verbose_name_plural = 'Course Videos'


class Course(models.Model):
    course_fac_id = models.CharField(max_length=100, blank=True, null=True)
    course_fac_name = models.CharField(max_length=100, blank=True, null=True)
    course_name = models.CharField(max_length=100, blank=True, null=True)
    course_request = models.IntegerField(blank=True, null=True)
    course_respond = models.IntegerField(blank=True, null=True)
    course_percent = models.IntegerField(blank=True, null=True)
    course_perform = models.CharField(max_length=100, blank=True, null=True)

    def __str__(self):
        return self.course_name

    class Meta:
        verbose_name_plural = 'Courses'


class QueryForm(models.Model):
    query_std_id = models.CharField(max_length=100, blank=True, null=True)
    query_fac_id = models.CharField(max_length=100, blank=True, null=True)
    query_course_name = models.CharField(max_length=100, blank=True, null=True)
    query_data = models.TextField(blank=True, null=True)
    query_data_ans = models.TextField(blank=True, null=True)
    query_solved = models.CharField(max_length=100, blank=True, null=True)

    def __str__(self):
        return self.query_data

    class Meta:
        verbose_name_plural = 'Query Form'


class StudentCourseAttend(models.Model):
    rep_std_id = models.CharField(max_length=100, blank=True, null=True)
    rep_std_name = models.CharField(max_length=100, blank=True, null=True)
    rep_course_name = models.CharField(max_length=100, blank=True, null=True)
    rep_course_topic = models.CharField(max_length=100, blank=True, null=True)
    rep_attend = models.CharField(max_length=100, blank=True, null=True)

    def __str__(self):
        return self.rep_course_name

    class Meta:
        verbose_name_plural = 'Student Course Attend'


class StudentAttendance(models.Model):
    att_std_id = models.CharField(max_length=100, blank=True, null=True)
    att_std_name = models.CharField(max_length=100, blank=True, null=True)
    att_tot_vid = models.IntegerField(blank=True, null=True)
    att_seen_vid = models.IntegerField(blank=True, null=True)
    att_percent = models.IntegerField(blank=True, null=True)
    att_perform = models.CharField(max_length=100, blank=True, null=True)
    att_exam = models.CharField(max_length=100, blank=True, null=True)

    def __str__(self):
        return self.att_std_name

    class Meta:
        verbose_name_plural = 'Student Attendance'
