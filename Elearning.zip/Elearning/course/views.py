from django.http import HttpResponse
from django.shortcuts import redirect
from django.template import loader
from course.models import *


def index(request):
    template = loader.get_template('index.html')
    context = {}
    request.session.flush()

    return HttpResponse(template.render(context, request))


def reg(request):
    template = loader.get_template('Register.html')
    context = {'mess': ''}
    request.session.flush()

    if request.method == 'POST':
        user_name = request.POST.get('user_name')
        user_pass = request.POST.get('user_pass')
        user_roll_no = str(request.POST.get('user_roll_no')).upper()
        user_role = request.POST.get('user_role')

        if context['mess'] == '':
            for x in Users.objects.all():
                if x.user_roll_no == user_roll_no:
                    context['mess'] = 'user already registered'

        if context['mess'] == '':
                ucobj = Users.objects.create(
                    user_name=user_name,
                    user_pass=user_pass,
                    user_roll_no=user_roll_no,
                    user_role=user_role
                )
                ucobj.save()

                if user_role == 'student':
                    vid_count = CourseVideo.objects.all().count()

                    saobj = StudentAttendance.objects.create()
                    saobj.att_std_id = user_roll_no
                    saobj.att_std_name = user_name
                    saobj.att_tot_vid = vid_count
                    saobj.att_seen_vid = 0
                    if vid_count != 0:
                        saobj.att_percent = 0
                    else:
                        saobj.att_percent = 100

                    if saobj.att_percent == 100:
                        saobj.att_perform = "Good"
                    else:
                        saobj.att_perform = "Detained"

                    saobj.save()

                context['mess'] = 'Registration Successful'

    return HttpResponse(template.render(context, request))


def login(request):
    template = loader.get_template('login.html')
    context = {}
    request.session.flush()

    if request.method == 'POST':

        user_roll_no = request.POST.get('user_roll_no')
        user_pass = request.POST.get('user_pass')

        for x in Users.objects.all():
            if x.user_roll_no == user_roll_no and x.user_pass == user_pass:
                request.session['user_roll_no'] = user_roll_no
                request.session['user_role'] = x.user_role

                if x.user_role == 'student':
                    return redirect(std_home)

                if x.user_role == 'faculty':
                    return redirect(fac_home)

                if x.user_role == 'adm':
                    return redirect(admin_student_list)

        context['message'] = "Permission denied, email or password in-correct"

    return HttpResponse(template.render(context, request))


def logout(request):
    if request.session.has_key('user_roll_no'):
        request.session.flush()
    else:
        return redirect(index)

    request.session.flush()

    return redirect(index)


# ---------------------- Faculty -------------------

def fac_home(request):
    template = loader.get_template('faculty/fac_home.html')
    context = {"mess": ""}
    if request.session.has_key('user_roll_no'):
        roll_no = request.session['user_roll_no']

        context['co'] = co = Course.objects.filter(course_fac_id=roll_no).order_by('course_name')

        if request.method == 'POST':
            if co.count() == 0:
                context['mess'] = "Please add Courses before uploading video"
            else:
                course_faculty_id = roll_no
                course_name = request.POST.get('course_name')
                course_video_title = str(request.POST.get('course_video_title')).upper()
                course_video = request.FILES['course_video']

                for x in CourseVideo.objects.all():
                    if x.course_name == course_name and x.course_video_title == course_video_title:
                        context['mess'] = "Topic Already Added"

                if context['mess'] == '':
                    cobj = CourseVideo.objects.create()
                    cobj.course_faculty_id = course_faculty_id
                    cobj.course_name = course_name
                    cobj.course_video = course_video
                    cobj.course_video_title = course_video_title

                    cobj.save()

                    vid_count = CourseVideo.objects.all().count()

                    for sa in StudentAttendance.objects.all():
                        sa.att_tot_vid = vid_count
                        sa.save()

                    context['mess'] = "Video Added Successfully"

    else:
        return redirect(index)

    return HttpResponse(template.render(context, request))


def fac_course(request):
    template = loader.get_template('faculty/fac_courses.html')
    context = {"mess": "", 'co': Course.objects.all().order_by('course_name')}
    if request.session.has_key('user_roll_no'):
        roll_no = request.session['user_roll_no']

        if request.method == 'POST':
            course_name = str(request.POST.get('course_name')).upper()

            for x in Course.objects.all():
                if x.course_name == course_name:
                    context['mess'] = "Course Already Added"

            if context['mess'] == '':
                cobj = Course.objects.create()
                cobj.course_fac_id = roll_no
                cobj.course_fac_name = (Users.objects.get(user_roll_no=roll_no)).user_name
                cobj.course_name = course_name
                cobj.course_request = 0
                cobj.course_respond = 0
                cobj.course_percent = 100
                cobj.course_perform = 'Good'

                cobj.save()

                return redirect('fac_course')
    else:
        return redirect(index)

    return HttpResponse(template.render(context, request))


def fac_course_topic(request, id):
    template = loader.get_template('faculty/fac_course_topic.html')
    context = {}
    if request.session.has_key('user_roll_no'):
        roll_no = request.session['user_roll_no']
        context['course_name'] = course_name = Course.objects.get(id=id)
        context['course_topics'] = CourseVideo.objects.filter(course_name=course_name)

    else:
        return redirect(index)

    return HttpResponse(template.render(context, request))


def fac_inbox(request):
    template = loader.get_template('faculty/fac_inbox.html')
    context = {}
    if request.session.has_key('user_roll_no'):
        context['fac_id'] = roll_no = request.session['user_roll_no']
        context['qf'] = QueryForm.objects.all()

    else:
        return redirect(index)

    return HttpResponse(template.render(context, request))


def fac_inbox_ans(request, id):
    template = loader.get_template('faculty/fac_inbox_replay.html')
    context = {}
    if request.session.has_key('user_roll_no'):
        roll_no = request.session['user_roll_no']

        context['qf'] = qf = QueryForm.objects.get(id=id)
        context['std'] = Users.objects.get(user_roll_no=qf.query_std_id)

        if request.method == 'POST':
            query_data_ans = request.POST.get('query_data_ans')
            qf.query_data_ans = query_data_ans
            qf.query_solved = 'yes'
            qf.save()

            return redirect('fac_inbox_ans_2')

    else:
        return redirect(index)

    return HttpResponse(template.render(context, request))


def fac_inbox_ans_2(request):
    template = loader.get_template('faculty/fac_inbox_reply_2.html')
    context = {}
    if request.session.has_key('user_roll_no'):
        roll_no = request.session['user_roll_no']

    else:
        return redirect(index)

    return HttpResponse(template.render(context, request))


def fac_profile(request):
    template = loader.get_template('faculty/fac_profile.html')
    context = {}
    if request.session.has_key('user_roll_no'):
        roll_no = request.session['user_roll_no']
        context['uo'] = uo = Users.objects.get(user_roll_no=roll_no)

        if request.method == 'POST':
            user_name = request.POST.get('user_name')
            user_pass = request.POST.get('user_pass')

            uo.user_name = user_name
            uo.user_pass = user_pass

            uo.save()

            context['mess'] = 'Profile Updated'

    else:
        return redirect(index)

    return HttpResponse(template.render(context, request))

# ---------------------- Student -------------------


def std_home(request):
    template = loader.get_template('student/std_home.html')
    context = {}
    if request.session.has_key('user_roll_no'):
        roll_no = request.session['user_roll_no']
        context['co'] = Course.objects.all().order_by('course_name')
    else:
        return redirect(index)

    return HttpResponse(template.render(context, request))


def std_course_topic(request, id):
    template = loader.get_template('student/std_home_topics.html')
    context = {}
    if request.session.has_key('user_roll_no'):
        roll_no = request.session['user_roll_no']
        context['c'] = c = Course.objects.get(id=id)
        context['ct'] = ct = CourseVideo.objects.filter(course_name=c.course_name).order_by('course_video_title')
    else:
        return redirect(index)

    return HttpResponse(template.render(context, request))


def std_course_topic_video(request, id):
    template = loader.get_template('student/std_home_topic_video.html')
    context = {}
    if request.session.has_key('user_roll_no'):
        roll_no = request.session['user_roll_no']
        context['ctv'] = ctv = CourseVideo.objects.get(id=id)
        context['std'] = std = Users.objects.get(user_roll_no=roll_no)
        context['fac'] = fac = Users.objects.get(user_roll_no=ctv.course_faculty_id)
        cc = 0
        for x in StudentCourseAttend.objects.all():
            if x.rep_std_id == roll_no and x.rep_course_name == ctv.course_name and x.rep_course_topic == ctv.course_video_title:
                cc = 1

        if cc == 0:
            sa = StudentCourseAttend.objects.create()
            sa.rep_course_name = ctv.course_name
            sa.rep_course_topic = ctv.course_video_title
            sa.rep_std_id = std.user_roll_no
            sa.rep_std_name = std.user_name
            sa.rep_attend = 'yes'
            sa.save()
    else:
        return redirect(index)

    return HttpResponse(template.render(context, request))


def std_query(request):
    template = loader.get_template('student/std_query.html')
    context = {'mess': ""}
    if request.session.has_key('user_roll_no'):
        roll_no = request.session['user_roll_no']
        context['co'] = Course.objects.all().order_by('course_name')

        if request.method == 'POST':
            course_name = request.POST.get('course_name')
            std_id = roll_no
            fac_id = (Course.objects.get(course_name=course_name)).course_fac_id
            data = request.POST.get('data')
            solved = "no"

            qf = QueryForm.objects.create()
            qf.query_std_id = std_id
            qf.query_fac_id = fac_id
            qf.query_course_name = course_name
            qf.query_data = data
            qf.query_solved = solved
            qf.query_data_ans = ""
            qf.save()

            context['mess'] = "Query Sent Successfully"
    else:
        return redirect(index)

    return HttpResponse(template.render(context, request))


def std_inbox(request):
    template = loader.get_template('student/std_inbox.html')
    context = {}
    if request.session.has_key('user_roll_no'):
        roll_no = request.session['user_roll_no']
        context['qf'] = QueryForm.objects.filter(query_std_id=roll_no).order_by('-id')

    else:
        return redirect(index)

    return HttpResponse(template.render(context, request))


def std_profile(request):
    template = loader.get_template('student/std_profile.html')
    context = {}
    if request.session.has_key('user_roll_no'):
        roll_no = request.session['user_roll_no']
        context['uo'] = uo = Users.objects.get(user_roll_no=roll_no)

        if request.method == 'POST':
            user_name = request.POST.get('user_name')
            user_pass = request.POST.get('user_pass')

            uo.user_name = user_name
            uo.user_pass = user_pass

            uo.save()

            context['mess'] = 'Profile Updated'

    else:
        return redirect(index)

    return HttpResponse(template.render(context, request))


# ----------------------- adm --------------

def admin_student_list(request):
    template = loader.get_template('adm/admin_std.html')
    context = {}
    if request.session.has_key('user_roll_no'):
        roll_no = request.session['user_roll_no']
        context['user_std'] = user = Users.objects.filter(user_role='student')
    else:
        return redirect(index)

    return HttpResponse(template.render(context, request))


def admin_faculty_list(request):
    template = loader.get_template('adm/admin_fac.html')
    context = {}
    if request.session.has_key('user_roll_no'):
        roll_no = request.session['user_roll_no']
        context['user_fac'] = user = Users.objects.filter(user_role='faculty')
    else:
        return redirect(index)

    return HttpResponse(template.render(context, request))


def admin_faculty_report(request):
    template = loader.get_template('adm/admin_fac_report.html')
    context = {}
    for co in Course.objects.all():

        tot = 0
        sol = 0
        for qf in QueryForm.objects.all():

            if co.course_name == qf.query_course_name:
                tot += 1
                if qf.query_solved == 'yes':
                    sol += 1

        co.course_request = tot
        co.course_respond = sol

        if tot != 0:
            p = (sol / tot) * 100
            co.course_percent = p

            if p >= 80:
                co.course_perform = 'Good'

            if p < 50:
                co.course_perform = 'Not Satisfied'

            if 50 <= p <= 79:
                co.course_perform = 'Average'

        co.save()

    if request.session.has_key('user_roll_no'):
        roll_no = request.session['user_roll_no']
        context['co'] = Course.objects.all().order_by('course_fac_id')

    else:
        return redirect(index)

    return HttpResponse(template.render(context, request))


def admin_std_report(request):
    template = loader.get_template('adm/admin_std_report.html')
    context = {}
    if request.session.has_key('user_roll_no'):
        roll_no = request.session['user_roll_no']
        tot = CourseVideo.objects.all().count()

        for sa in StudentAttendance.objects.all():
            sol = 0
            for sca in StudentCourseAttend.objects.filter(rep_std_id=sa.att_std_id):
                if sca.rep_attend == 'yes':
                   sol += 1
            sa.att_seen_vid = sol
            sa.att_tot_vid = tot
            sa.att_exam = 'yes'
            if tot != 0:
                p = (sol / tot) * 100
                sa.att_percent = p

                if p >= 75:
                    sa.att_perform = 'Good'

                if p < 50:
                    sa.att_perform = 'Detained'
                    sa.att_exam = 'no'

                if 50 <= p <= 74:
                    sa.att_perform = 'Need to be improved'
            sa.save()

        context['stdrep'] = stdrep = StudentAttendance.objects.all().order_by('att_std_id')

    else:
        return redirect(index)

    return HttpResponse(template.render(context, request))
